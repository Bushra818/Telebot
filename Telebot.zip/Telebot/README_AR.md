# Telegram Archiver Bot — حزمة Mini App

هذه الحزمة تحتوي على نسخة البوت التي لا تثبّت FastAPI أو Uvicorn أثناء التشغيل. يجب أن تقوم المنصة بتثبيت المكتبات من `requirements.txt` قبل تشغيل البوت.

## محتويات الحزمة

- `bot_multi.py`: ملف البوت وواجهة Telegram Mini App.
- `requirements.txt`: مكتبات التشغيل.

لا تتضمن الحزمة ملفات الجلسات أو أي رموز سرية. أعد رفع مجلد `sessions` من النسخة الاحتياطية إلى مسار التطبيق بعد تثبيت الحزمة.

## إعداد JustRunMy.App

ضع الملفات في مجلد التطبيق نفسه، بجانب مجلد `sessions`:

```text
/app/telegram_archiver_bot/
├── bot_multi.py
├── requirements.txt
└── sessions/
```

أمر التشغيل:

```bash
python3 bot_multi.py
```

يجب أن يكون المنفذ `8080` أو قيمة `PORT` التي تحددها المنصة، ويجب أن تكون الخدمة Web Service وليست Worker فقط.

## متغيرات البيئة المطلوبة

```env
TELEGRAM_API_ID=...
TELEGRAM_API_HASH=...
BOT_TOKEN=...
OWNER_ID=8792272807
WEB_PUBLIC_BASE_URL=https://رابط-المنفذ-العام
PORT=8080
SESSION_DIR=./sessions
```

استخدم أسماء المتغيرات كما هي تماماً. لا تستخدم `API_ID` أو `API_HASH` بدلاً من `TELEGRAM_API_ID` و`TELEGRAM_API_HASH`.

## صلاحية Mini App

التحقق موجود داخل الكود، والـ Mini App تسمح فقط للمستخدم الذي يساوي `OWNER_ID`. أي مستخدم آخر يحصل على رفض `403` قبل الوصول إلى أي جلسة أو API.

تأكد أن قيمة `OWNER_ID` هي رقم حساب Telegram للمالك فقط.

## بعد رفع الملفات

1. ارفع مجلد `sessions` من النسخة الاحتياطية إلى نفس مسار التطبيق.
2. ثبّت `requirements.txt` عبر Build أو عبر Terminal قبل التشغيل.
3. شغّل البوت.
4. تحقق من السجل حتى يظهر:

```text
WEB_READY: http://0.0.0.0:8080
```

5. اختبر:

```text
https://رابط-المنفذ-العام/healthz
```

يجب أن يعيد الطلب حالة `200` وحقول `ok`, `web`, و`mini_app`.

## أمان

لا ترفع إلى الحزمة أو Git الملفات التالية:

- `BOT_TOKEN`
- `TELEGRAM_API_HASH`
- ملفات `sessions/*.session`
- ملف النسخة الاحتياطية المضغوط للجلسات

إذا ظهر Bot Token في سجل أو صورة، قم بتغييره من `@BotFather`.
